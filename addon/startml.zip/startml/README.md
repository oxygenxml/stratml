stratml
=======

An oXygen XML Editor framework to add StratML support to oXygen